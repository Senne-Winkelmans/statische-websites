function function1(){
    document.getElementById('demo').innerHTML = Date();
}